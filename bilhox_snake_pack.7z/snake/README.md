# snake_python_pygame
Simple snake game on Python with Pygame module
